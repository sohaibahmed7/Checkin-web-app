document.addEventListener('DOMContentLoaded', () => {
    // Initialize Mapbox with the correct token
    mapboxgl.accessToken = 'pk.eyJ1IjoiYW5zaG1ha2thciIsImEiOiJjbTl2ams5OGcwbGwwMm1vbGpiaDduczg1In0.4yzUyxSxV9lHLtbRQfjdWA';
    
    // Add navigation handlers
    document.querySelectorAll('[data-navigate-to]').forEach(element => {
        element.addEventListener('click', (e) => {
            e.preventDefault();
            const targetTab = element.getAttribute('data-navigate-to');
            const tabLink = document.querySelector(`a[data-tab="${targetTab}"]`);
            if (tabLink) {
                tabLink.click();
            }
        });
    });

    let map = null;
    let mapFull = null;
    let liveMap = null;
    let userMarker = null;

    // Helper function to get marker color based on type
    function getMarkerColor(type) {
        const colors = {
            suspicious: '#D32F2F', // Darker red for suspicious activity
            fire: '#E65100',      // Darker orange for fire alerts
            community: '#00796B', // Darker teal for community updates
            theft: '#F57C00',     // Darker yellow for theft
            noise: '#4A148C',     // Darker purple for noise complaints
            default: '#1A237E'    // Darker blue for default
        };
        return colors[type] || colors.default;
    }

    // Initialize home page map
    function initializeHomeMap() {
        const homeMapContainer = document.getElementById('map');
        if (!homeMapContainer) return;
        
        map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/streets-v12',
            center: [-81.24, 43.02], // London, ON coordinates
            zoom: 13
        });

        // Add navigation controls
        map.addControl(new mapboxgl.NavigationControl());

        // Add sample markers with descriptions
        const markers = [
            {
                coordinates: [-81.24, 43.02],
                type: 'suspicious',
                description: 'Suspicious vehicle spotted - Silver van circling Elm Street',
                time: '5m ago',
                user: 'Mike R.'
            },
            {
                coordinates: [-81.25, 43.01],
                type: 'fire',
                description: 'Fire reported at Oak & Main. Fire department en route',
                time: '15m ago',
                user: 'John D.'
            },
            {
                coordinates: [-81.23, 43.03],
                type: 'community',
                description: 'Neighborhood watch starting evening rounds. All clear so far',
                time: '30m ago',
                user: 'Sarah M.'
            }
        ];

        markers.forEach(marker => {
            const el = document.createElement('div');
            el.className = 'marker';
            el.style.backgroundColor = getMarkerColor(marker.type);
            el.style.width = '28px';
            el.style.height = '28px';
            el.style.borderRadius = '50%';
            el.style.border = '3px solid white';
            el.style.boxShadow = '0 0 0 3px ' + getMarkerColor(marker.type);
            el.style.zIndex = '1000';

            const popup = new mapboxgl.Popup({ offset: 25 })
                .setHTML(`
                    <div class="map-popup">
                        <div class="popup-header">
                            <span class="popup-user">${marker.user}</span>
                            <span class="popup-time">${marker.time}</span>
                        </div>
                        <p class="popup-message">${marker.description}</p>
                    </div>
                `);

            new mapboxgl.Marker(el)
                .setLngLat(marker.coordinates)
                .setPopup(popup)
                .addTo(map);
        });
    }

    // Initialize full map
    function initializeMapFull() {
        const mapContainer = document.getElementById('map-full');
        if (!mapContainer) return;
        
        mapFull = new mapboxgl.Map({
            container: 'map-full',
            style: 'mapbox://styles/mapbox/streets-v12',
            center: [-81.24, 43.02], // London, ON coordinates
            zoom: 13
        });
        
        // Add navigation controls
        mapFull.addControl(new mapboxgl.NavigationControl());

        // Add sample markers with descriptions
        const markers = [
            {
                coordinates: [-81.24, 43.02],
                type: 'suspicious',
                description: 'Suspicious vehicle spotted - Silver van circling Elm Street',
                time: '5m ago',
                user: 'Mike R.'
            },
            {
                coordinates: [-81.25, 43.01],
                type: 'fire',
                description: 'Fire reported at Oak & Main. Fire department en route',
                time: '15m ago',
                user: 'John D.'
            },
            {
                coordinates: [-81.23, 43.03],
                type: 'community',
                description: 'Neighborhood watch starting evening rounds. All clear so far',
                time: '30m ago',
                user: 'Sarah M.'
            }
        ];

        markers.forEach(marker => {
            const el = document.createElement('div');
            el.className = 'marker';
            el.style.backgroundColor = getMarkerColor(marker.type);
            el.style.width = '28px';
            el.style.height = '28px';
            el.style.borderRadius = '50%';
            el.style.border = '3px solid white';
            el.style.boxShadow = '0 0 0 3px ' + getMarkerColor(marker.type);
            el.style.zIndex = '1000';

            const popup = new mapboxgl.Popup({ offset: 25 })
                .setHTML(`
                    <div class="map-popup">
                        <div class="popup-header">
                            <span class="popup-user">${marker.user}</span>
                            <span class="popup-time">${marker.time}</span>
                        </div>
                        <p class="popup-message">${marker.description}</p>
                    </div>
                `);

            new mapboxgl.Marker(el)
                .setLngLat(marker.coordinates)
                .setPopup(popup)
                .addTo(mapFull);
        });
    }

    // Initialize live map
    function initializeLiveMap() {
        const liveMapContainer = document.getElementById('live-map-full');
        if (!liveMapContainer) return;
        
        liveMap = new mapboxgl.Map({
            container: 'live-map-full',
            style: 'mapbox://styles/mapbox/streets-v12',
            center: [-81.24, 43.02], // London, ON coordinates
            zoom: 13
        });
        
        // Add navigation controls
        liveMap.addControl(new mapboxgl.NavigationControl());

        // Add initial markers
        let currentTimeFilter = '24h';
        addMarkersToMap(liveMap, filterPings('all', currentTimeFilter));

        // Set up category filters
        const categoryButtons = document.querySelectorAll('.live-map-controls .category-toggles button');
        categoryButtons.forEach(button => {
            button.addEventListener('click', () => {
                categoryButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                
                const category = button.getAttribute('data-category');
                
                // Remove existing markers
                if (currentMarkers && currentMarkers.length) {
                    currentMarkers.forEach(marker => marker.remove());
                    currentMarkers = [];
                }
                
                // Add filtered markers
                const filteredPings = filterPings(category, currentTimeFilter);
                addMarkersToMap(liveMap, filteredPings);
            });
        });

        // Set up time filter
        const timeFilter = document.getElementById('live-time-filter');
        if (timeFilter) {
            timeFilter.addEventListener('change', (e) => {
                currentTimeFilter = e.target.value;
                const activeCategory = document.querySelector('.category-toggles button.active').getAttribute('data-category');
                
                // Remove existing markers
                if (currentMarkers && currentMarkers.length) {
                    currentMarkers.forEach(marker => marker.remove());
                    currentMarkers = [];
                }
                
                // Add filtered markers
                const filteredPings = filterPings(activeCategory, currentTimeFilter);
                addMarkersToMap(liveMap, filteredPings);
            });
        }
    }

    // Helper function to add markers to map
    function addMarkersToMap(map, pings) {
        currentMarkers = pings.map(ping => {
            const el = document.createElement('div');
            el.className = `marker ${ping.type}`;
            el.style.backgroundColor = getMarkerColor(ping.type);
            el.style.width = '28px';
            el.style.height = '28px';
            el.style.borderRadius = '50%';
            el.style.border = '3px solid white';
            el.style.boxShadow = '0 0 0 3px ' + getMarkerColor(ping.type);
            el.style.zIndex = '1000';

            const popup = new mapboxgl.Popup({ offset: 25 })
                .setHTML(`
                    <div class="map-popup">
                        <div class="popup-header">
                            <span class="popup-user">${ping.author}</span>
                            <span class="popup-time">${formatTimestamp(ping.timestamp)}</span>
                        </div>
                        <p class="popup-message">${ping.description}</p>
                    </div>
                `);

            const marker = new mapboxgl.Marker(el)
                .setLngLat(ping.coordinates)
                .setPopup(popup)
                .addTo(map);

            return marker;
        });
    }

    // Initialize maps based on active tab
    if (document.querySelector('.tab-pane.active#home')) {
        initializeHomeMap();
    } else if (document.querySelector('.tab-pane.active#map')) {
        initializeMapFull();
    } else if (document.querySelector('.tab-pane.active#live-map')) {
        initializeLiveMap();
    }

    // Add event listener for window resize
    window.addEventListener('resize', () => {
        if (map) map.resize();
        if (mapFull) mapFull.resize();
        if (liveMap) liveMap.resize();
    });

    // Tab Navigation with map initialization
    const tabLinks = document.querySelectorAll('.sidebar-nav a');
    const tabPanes = document.querySelectorAll('.tab-pane');

    tabLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Remove active class from all links and panes
            tabLinks.forEach(l => l.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            
            // Add active class to clicked link and corresponding pane
            link.classList.add('active');
            const targetId = link.getAttribute('href').substring(1);
            const targetPane = document.getElementById(targetId);
            targetPane.classList.add('active');

            // Initialize appropriate map based on tab
            setTimeout(() => {
                if (targetId === 'home' && !map) {
                    initializeHomeMap();
                } else if (targetId === 'map' && !mapFull) {
                    initializeMapFull();
                } else if (targetId === 'live-map' && !liveMap) {
                    initializeLiveMap();
                }

                // Resize the appropriate map
                if (targetId === 'home' && map) map.resize();
                if (targetId === 'map' && mapFull) mapFull.resize();
                if (targetId === 'live-map' && liveMap) liveMap.resize();
            }, 100);
        });
    });

    // Category Filters
    const categoryFilters = document.querySelectorAll('.category-filter');
    categoryFilters.forEach(button => {
        button.addEventListener('click', function() {
            categoryFilters.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            const selectedCategory = this.getAttribute('data-category');
            filterPings(selectedCategory);
        });
    });

    // Time Filter
    const timeFilter = document.querySelector('.time-filter');
    if (timeFilter) {
        timeFilter.addEventListener('change', function(e) {
            filterPingsByTime(e.target.value);
        });
    }

    // Place Ping Button
    const placePingBtn = document.getElementById('place-ping');
    const pinModal = document.getElementById('pin-modal');
    
    if (placePingBtn) {
        placePingBtn.addEventListener('click', function() {
            const activeMap = document.getElementById('map').classList.contains('active') ? map : mapFull;
            if (!activeMap) return;

            activeMap.getCanvas().style.cursor = 'crosshair';
            
            const onClick = (e) => {
                const coordinates = e.lngLat;
                
                // Create a new ping at the clicked location
                const el = document.createElement('div');
                el.className = 'marker new-ping';
                
                new mapboxgl.Marker(el)
                    .setLngLat(coordinates)
                    .addTo(activeMap);
                
                // Reset cursor and remove click handler
                activeMap.getCanvas().style.cursor = '';
                activeMap.off('click', onClick);
                
                // Show pin modal if it exists
                if (pinModal) {
                    document.getElementById('pin-location').value = `${coordinates.lat}, ${coordinates.lng}`;
                    pinModal.classList.add('active');
                }
            };
            
            activeMap.once('click', onClick);
        });
    }

    // Pin Modal
    if (pinModal) {
        const closePinModal = document.getElementById('close-pin-modal');
        if (closePinModal) {
            closePinModal.addEventListener('click', () => {
                pinModal.classList.remove('active');
            });
        }

        // Photo Upload
        const photoUpload = document.querySelector('.photo-upload');
        const photoInput = document.getElementById('pin-photo');

        if (photoUpload && photoInput) {
            photoUpload.addEventListener('click', () => {
                photoInput.click();
            });

            photoInput.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        photoUpload.innerHTML = `<img src="${e.target.result}" style="max-width: 100%; max-height: 200px;">`;
                    };
                    reader.readAsDataURL(this.files[0]);
                }
            });
        }

        // Pin Form Submission
        const pinForm = document.querySelector('.pin-modal-form');
        if (pinForm) {
            pinForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const location = document.getElementById('pin-location').value;
                const type = document.getElementById('pin-type').value;
                const description = document.getElementById('pin-description').value;
                const photo = document.getElementById('pin-photo').files[0];

                createPin(location, type, description, photo);
                pinModal.classList.remove('active');
                pinForm.reset();
                if (photoUpload) {
                    photoUpload.innerHTML = 'Drop your photo here or click to upload';
                }
            });
        }
    }

    // Helper Functions
    function createPin(location, type, description, photo) {
        const [lat, lng] = location.split(',').map(coord => parseFloat(coord.trim()));
        const activeMap = document.getElementById('map').classList.contains('active') ? map : mapFull;
        
        if (!activeMap) return;

        const marker = new mapboxgl.Marker({
            color: getPinColor(type),
            draggable: false
        })
        .setLngLat([lng, lat])
        .setPopup(new mapboxgl.Popup({ offset: 25 })
            .setHTML(`
                <div class="pin-tooltip">
                    <span class="pin-category ${type}">${type}</span>
                    <p class="pin-message">${description}</p>
                    ${photo ? `<img src="${URL.createObjectURL(photo)}" style="max-width: 100%; max-height: 150px;">` : ''}
                    <div class="pin-actions">
                        <button class="view-more-btn">View More</button>
                    </div>
                </div>
            `))
        .addTo(activeMap);

        marker.getElement().addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.1)';
        });

        marker.getElement().addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    }

    function getPinColor(type) {
        const colors = {
            suspicious: '#ffc107',
            theft: '#28a745',
            fire: '#dc3545',
            noise: '#17a2b8'
        };
        return colors[type] || '#4a6bff';
    }

    function filterPings(category) {
        // Remove all existing markers
        currentMarkers.forEach(marker => marker.remove());
        currentMarkers = [];

        // Filter pings based on category
        let filteredPings = allPings;
        if (category !== 'all') {
            filteredPings = allPings.filter(ping => ping.type === category);
        }

        // Add filtered markers to the map
        const activeMap = document.getElementById('map').classList.contains('active') ? map :
                         document.getElementById('live-map').classList.contains('active') ? liveMap :
                         mapFull;

        if (activeMap) {
            filteredPings.forEach(ping => {
                const el = document.createElement('div');
                el.className = `marker ${ping.type}`;
                el.style.backgroundColor = getMarkerColor(ping.type);
                el.style.width = '28px';
                el.style.height = '28px';
                el.style.borderRadius = '50%';
                el.style.border = '3px solid white';
                el.style.boxShadow = '0 0 0 3px ' + getMarkerColor(ping.type);
                el.style.zIndex = '1000';

                const popup = new mapboxgl.Popup({ offset: 25 })
                    .setHTML(`
                        <div class="map-popup">
                            <div class="popup-header">
                                <span class="popup-user">${ping.author}</span>
                                <span class="popup-time">${formatTimestamp(ping.timestamp)}</span>
                            </div>
                            <p class="popup-message">${ping.description}</p>
                        </div>
                    `);

                const marker = new mapboxgl.Marker(el)
                    .setLngLat(ping.coordinates)
                    .setPopup(popup)
                    .addTo(activeMap);

                currentMarkers.push(marker);
            });
        }

        // Update the pings feed to match the filtered pings
        updatePingsFeed(filteredPings);
    }

    function filterPingsByTime(timeRange) {
        // Implementation for time-based filtering
        console.log('Filtering by time:', timeRange);
    }

    // Handle "View on Map" clicks
    document.querySelectorAll('.view-on-map, .view-location').forEach(element => {
        element.addEventListener('click', (e) => {
            e.preventDefault();
            const coordinates = element.dataset.coordinates.split(',').map(Number);
            
            // Switch to map tab
            const mapLink = document.querySelector('a[data-tab="map"]');
            mapLink.click();
            
            // Fly to the coordinates
            setTimeout(() => {
                if (mapFull) {
                    mapFull.flyTo({
                        center: coordinates,
                        zoom: 15
                    });

                    // Add a temporary marker
                    new mapboxgl.Marker({
                        color: '#ff4444'
                    })
                    .setLngLat(coordinates)
                    .addTo(mapFull);
                }
            }, 100);
        });
    });

    // Update Ping Location function to handle live map
    window.pingLocation = () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(position => {
                const { longitude, latitude } = position.coords;
                if (userMarker) userMarker.setLngLat([longitude, latitude]);
                
                const activeMap = document.getElementById('map').classList.contains('active') ? map :
                                document.getElementById('live-map').classList.contains('active') ? liveMap :
                                mapFull;
                
                if (activeMap) {
                    activeMap.flyTo({
                        center: [longitude, latitude],
                        zoom: 15
                    });
                }
                
                const locationInput = document.getElementById('pin-location');
                if (locationInput) {
                    locationInput.value = `${latitude}, ${longitude}`;
                }
            });
        }
    };

    // Sample data structure for pings with more information
    const allPings = [
        {
            id: 1,
            coordinates: [-81.2452, 43.0096],
            type: 'suspicious',
            description: 'Suspicious vehicle reported - Black sedan circling the area',
            author: 'John Smith',
            timestamp: new Date(Date.now() - 1000 * 60 * 15) // 15 minutes ago
        },
        {
            id: 2,
            coordinates: [-81.2352, 43.0196],
            type: 'community',
            description: 'Community gathering - Weekend farmers market this Saturday',
            author: 'Emma Davis',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2) // 2 days ago
        },
        {
            id: 3,
            coordinates: [-81.2552, 43.0146],
            type: 'fire',
            description: 'Fire reported at Oak & Main - Fire department on scene',
            author: 'Mike Johnson',
            timestamp: new Date(Date.now() - 1000 * 60 * 5) // 5 minutes ago
        },
        {
            id: 4,
            coordinates: [-81.2652, 43.0246],
            type: 'suspicious',
            description: 'Unknown person checking car doors in parking lot',
            author: 'Sarah Wilson',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5) // 5 days ago
        },
        {
            id: 5,
            coordinates: [-81.2252, 43.0046],
            type: 'fire',
            description: 'Small brush fire in Richmond Park',
            author: 'Tom Brown',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10) // 10 days ago
        },
        {
            id: 6,
            coordinates: [-81.2152, 43.0296],
            type: 'community',
            description: 'Lost dog found - Golden Retriever',
            author: 'Lisa Chen',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 15) // 15 days ago
        },
        {
            id: 7,
            coordinates: [-81.2752, 43.0346],
            type: 'suspicious',
            description: 'Unusual drone activity over residential area',
            author: 'Mark Davis',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 20) // 20 days ago
        },
        {
            id: 8,
            coordinates: [-81.2852, 43.0446],
            type: 'fire',
            description: 'Kitchen fire reported - Now contained',
            author: 'Amy Wong',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 25) // 25 days ago
        }
    ];

    let currentMarkers = [];
    let currentFilter = 'all';
    let currentTimeFilter = '24h';

    // Helper function to format timestamps
    function formatTimestamp(timestamp) {
        const now = new Date();
        const diff = now - timestamp;
        const minutes = Math.floor(diff / 1000 / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (days > 0) return `${days}d ago`;
        if (hours > 0) return `${hours}h ago`;
        return `${minutes}m ago`;
    }

    // Function to create a modern ping marker
    function createModernPingMarker(ping, targetMap) {
        const el = document.createElement('div');
        el.className = `marker ${ping.type}`;
        
        // Create popup with timestamp
        const popup = new mapboxgl.Popup({
            offset: 25,
            closeButton: false,
            closeOnClick: false
        }).setHTML(`
            <div class="ping-tooltip">
                <span class="ping-category ${ping.type}">${ping.type}</span>
                <p class="ping-message">${ping.description}</p>
                <span class="ping-timestamp">${formatTimestamp(ping.timestamp)}</span>
            </div>
        `);

        // Create and return the marker
        const marker = new mapboxgl.Marker(el)
            .setLngLat(ping.coordinates)
            .setPopup(popup)
            .addTo(targetMap);

        // Show popup by default
        popup.addTo(targetMap);
        
        return marker;
    }

    // Function to update the pings feed
    function updatePingsFeed(filteredPings) {
        const feedContainer = document.querySelector('.pings-list');
        if (!feedContainer) return;

        feedContainer.innerHTML = '';
        
        filteredPings.forEach(ping => {
            const pingElement = document.createElement('div');
            pingElement.className = `ping-item ${ping.type}`;
            pingElement.innerHTML = `
                <div class="ping-header">
                    <div class="ping-user">
                        <img src="assets/avatar.svg" alt="${ping.author}">
                        <div class="ping-user-info">
                            <h4>${ping.author}</h4>
                            <span class="ping-time">${formatTimestamp(ping.timestamp)}</span>
                        </div>
                    </div>
                    <span class="ping-category ${ping.type}">${ping.type}</span>
                </div>
                <div class="ping-content">
                    <p>${ping.description}</p>
                </div>
                <div class="ping-replies">
                    ${ping.replies.map(reply => `
                        <div class="reply">
                            <img src="assets/avatar.svg" alt="${reply.author}">
                            <div class="reply-content">
                                <h5>${reply.author} <span>${formatTimestamp(reply.timestamp)}</span></h5>
                                <p>${reply.text}</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
                <div class="ping-actions">
                    <button class="action-btn reply-btn" data-ping-id="${ping.id}">
                        <i class="fas fa-reply"></i> Reply
                    </button>
                    <button class="action-btn view-btn" data-coordinates="${ping.coordinates}">
                        <i class="fas fa-map-marker-alt"></i> View on Map
                    </button>
                </div>
            `;
            feedContainer.appendChild(pingElement);
        });

        // Add event listeners for reply buttons
        document.querySelectorAll('.reply-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const pingId = e.currentTarget.dataset.pingId;
                showReplyForm(pingId);
            });
        });

        // Add event listeners for view buttons
        document.querySelectorAll('.view-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const coords = e.currentTarget.dataset.coordinates.split(',').map(Number);
                if (liveMap) {
                    liveMap.flyTo({
                        center: coords,
                        zoom: 15
                    });
                }
            });
        });
    }

    // Function to show reply form
    function showReplyForm(pingId) {
        const ping = allPings.find(p => p.id === parseInt(pingId));
        if (!ping) return;

        const replyForm = document.createElement('div');
        replyForm.className = 'reply-form';
        replyForm.innerHTML = `
            <textarea placeholder="Write your reply..."></textarea>
            <div class="reply-form-actions">
                <button class="cancel-reply">Cancel</button>
                <button class="submit-reply">Reply</button>
            </div>
        `;

        const pingElement = document.querySelector(`[data-ping-id="${pingId}"]`).closest('.ping-item');
        pingElement.querySelector('.ping-actions').insertAdjacentElement('beforebegin', replyForm);

        // Add event listeners for reply form
        replyForm.querySelector('.submit-reply').addEventListener('click', () => {
            const replyText = replyForm.querySelector('textarea').value;
            if (replyText.trim()) {
                ping.replies.push({
                    author: 'You', // In a real app, this would be the logged-in user
                    text: replyText,
                    timestamp: new Date()
                });
                updatePingsFeed(filterPings());
            }
            replyForm.remove();
        });

        replyForm.querySelector('.cancel-reply').addEventListener('click', () => {
            replyForm.remove();
        });
    }

    // Function to filter pings based on category and time
    function filterPings(category, timeRange) {
        let filteredPings = [...allPings];
        
        // Apply time filter
        const now = new Date();
        switch(timeRange) {
            case '24h':
                filteredPings = filteredPings.filter(ping => 
                    (now - ping.timestamp) <= 1000 * 60 * 60 * 24
                );
                break;
            case '7d':
                filteredPings = filteredPings.filter(ping => 
                    (now - ping.timestamp) <= 1000 * 60 * 60 * 24 * 7
                );
                break;
            case '30d':
                filteredPings = filteredPings.filter(ping => 
                    (now - ping.timestamp) <= 1000 * 60 * 60 * 24 * 30
                );
                break;
        }
        
        // Apply category filter
        if (category !== 'all') {
            filteredPings = filteredPings.filter(ping => ping.type === category);
        }
        
        return filteredPings;
    }

    // Function to update map markers
    function updateMapMarkers(targetMap) {
        // Clear existing markers
        currentMarkers.forEach(marker => marker.remove());
        currentMarkers = [];

        // Add new filtered markers
        const filteredPings = filterPings();
        filteredPings.forEach(ping => {
            const marker = createModernPingMarker(ping, targetMap);
            currentMarkers.push(marker);
        });

        // Update the pings feed
        updatePingsFeed(filteredPings);
    }

    // Initialize Activity Chart
    function initializeActivityChart() {
        const ctx = document.getElementById('activityChart');
        if (!ctx) return;

        // Sample data for the past 30 days
        const dates = Array.from({length: 30}, (_, i) => {
            const d = new Date();
            d.setDate(d.getDate() - (29 - i));
            return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        });

        const alerts = Array.from({length: 30}, () => Math.floor(Math.random() * 15 + 5)); // Random data between 5-20

        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: dates,
                datasets: [{
                    label: 'Alerts',
                    data: alerts,
                    borderColor: '#3B82F6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    borderWidth: 2,
                    pointBackgroundColor: '#3B82F6',
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    fill: true,
                    tension: 0.4,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: 'white',
                        titleColor: '#111827',
                        bodyColor: '#111827',
                        borderColor: '#E5E7EB',
                        borderWidth: 1,
                        padding: 12,
                        displayColors: false,
                        callbacks: {
                            title: (items) => {
                                return items[0].label;
                            },
                            label: (item) => {
                                return `${item.formattedValue} alerts`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                size: 12
                            },
                            color: '#6B7280'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#F3F4F6'
                        },
                        ticks: {
                            font: {
                                size: 12
                            },
                            color: '#6B7280',
                            stepSize: 5
                        }
                    }
                }
            }
        });

        // Handle filter buttons
        const filterButtons = document.querySelectorAll('.chart-filters button');
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                
                // Update chart data based on filter
                let newDates, newData;
                switch(button.textContent.toLowerCase()) {
                    case 'week':
                        newDates = dates.slice(-7);
                        newData = alerts.slice(-7);
                        break;
                    case 'month':
                        newDates = dates;
                        newData = alerts;
                        break;
                    case 'year':
                        // For demo, just show more data points
                        newDates = [...dates, ...dates].slice(-365);
                        newData = [...alerts, ...alerts].slice(-365);
                        break;
                }
                
                chart.data.labels = newDates;
                chart.data.datasets[0].data = newData;
                chart.update();
            });
        });
    }

    // Initialize Reports Activity Chart
    const reportsActivityCtx = document.getElementById('reportsActivityChart');
    if (reportsActivityCtx) {
        // Sample data for different time periods
        const chartData = {
            week: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                data: [12, 19, 15, 17, 14, 23, 21]
            },
            month: {
                labels: ['Jan', 'Feb', 'Mar'],
                data: [145, 132, 168]
            },
            year: {
                labels: ['2022', '2023', '2024'],
                data: [1245, 1532, 1368]
            }
        };

        const reportsChart = new Chart(reportsActivityCtx, {
            type: 'line',
            data: {
                labels: chartData.week.labels,
                datasets: [{
                    label: 'Reports',
                    data: chartData.week.data,
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: 'white',
                        titleColor: '#111827',
                        bodyColor: '#111827',
                        borderColor: '#E5E7EB',
                        borderWidth: 1,
                        padding: 12,
                        displayColors: false,
                        callbacks: {
                            title: (items) => items[0].label,
                            label: (item) => `${item.formattedValue} reports`
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            display: true,
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            callback: function(value) {
                                if (value >= 1000) {
                                    return value / 1000 + 'k';
                                }
                                return value;
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });

        // Add event listeners for time period filters
        const filterButtons = document.querySelectorAll('.activity-chart-section .chart-filters button');
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                button.classList.add('active');

                // Get the time period from the button text
                const period = button.textContent.toLowerCase();
                
                // Update chart data
                reportsChart.data.labels = chartData[period].labels;
                reportsChart.data.datasets[0].data = chartData[period].data;

                // Update chart stats based on the period
                updateChartStats(period);

                // Animate the update
                reportsChart.update('active');
            });
        });

        // Function to update stats below the chart
        function updateChartStats(period) {
            const statsContainer = document.querySelector('.chart-stats');
            if (!statsContainer) return;

            const stats = {
                week: {
                    total: '124',
                    totalChange: '+12%',
                    responseTime: '8m',
                    responseChange: '-5%',
                    resolution: '92%',
                    resolutionChange: '+3%'
                },
                month: {
                    total: '445',
                    totalChange: '+8%',
                    responseTime: '10m',
                    responseChange: '-2%',
                    resolution: '89%',
                    resolutionChange: '+5%'
                },
                year: {
                    total: '4,145',
                    totalChange: '+15%',
                    responseTime: '12m',
                    responseChange: '+3%',
                    resolution: '94%',
                    resolutionChange: '+7%'
                }
            };

            const currentStats = stats[period];
            
            // Update total reports
            const totalValue = statsContainer.querySelector('.stat-item:nth-child(1) .stat-value');
            const totalChange = statsContainer.querySelector('.stat-item:nth-child(1) .stat-change');
            if (totalValue) totalValue.textContent = currentStats.total;
            if (totalChange) {
                totalChange.textContent = currentStats.totalChange + ' ';
                totalChange.className = 'stat-change ' + (currentStats.totalChange.includes('+') ? 'positive' : 'negative');
                totalChange.innerHTML += `<i class="fas fa-arrow-${currentStats.totalChange.includes('+') ? 'up' : 'down'}"></i>`;
            }

            // Update response time
            const responseValue = statsContainer.querySelector('.stat-item:nth-child(2) .stat-value');
            const responseChange = statsContainer.querySelector('.stat-item:nth-child(2) .stat-change');
            if (responseValue) responseValue.textContent = currentStats.responseTime;
            if (responseChange) {
                responseChange.textContent = currentStats.responseChange + ' ';
                responseChange.className = 'stat-change ' + (currentStats.responseChange.includes('+') ? 'negative' : 'positive');
                responseChange.innerHTML += `<i class="fas fa-arrow-${currentStats.responseChange.includes('+') ? 'up' : 'down'}"></i>`;
            }

            // Update resolution rate
            const resolutionValue = statsContainer.querySelector('.stat-item:nth-child(3) .stat-value');
            const resolutionChange = statsContainer.querySelector('.stat-item:nth-child(3) .stat-change');
            if (resolutionValue) resolutionValue.textContent = currentStats.resolution;
            if (resolutionChange) {
                resolutionChange.textContent = currentStats.resolutionChange + ' ';
                resolutionChange.className = 'stat-change ' + (currentStats.resolutionChange.includes('+') ? 'positive' : 'negative');
                resolutionChange.innerHTML += `<i class="fas fa-arrow-${currentStats.resolutionChange.includes('+') ? 'up' : 'down'}"></i>`;
            }
        }
    }

    initializeActivityChart();
});

// Chat Panel Toggle
const chatToggle = document.querySelector('.chat-toggle');
const chatPanel = document.querySelector('.chat-panel');

if (chatToggle && chatPanel) {
    chatToggle.addEventListener('click', () => {
        chatPanel.style.display = chatPanel.style.display === 'flex' ? 'none' : 'flex';
    });

    // Close Chat Panel
    const closeChat = document.querySelector('.close-chat');
    if (closeChat) {
        closeChat.addEventListener('click', () => {
            chatPanel.style.display = 'none';
        });
    }
}

// User Menu Dropdown
const userAvatar = document.querySelector('.user-avatar');
const dropdownMenu = document.querySelector('.dropdown-menu');

if (userAvatar && dropdownMenu) {
    userAvatar.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
    });

    document.addEventListener('click', () => {
        dropdownMenu.style.display = 'none';
    });
}

// Map Filters
const categoryButtons = document.querySelectorAll('.category-toggles button');
categoryButtons.forEach(button => {
    button.addEventListener('click', () => {
        categoryButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        const selectedCategory = button.getAttribute('data-category');
        filterPings(selectedCategory);
    });
});

// Reports Table Functionality
// Handle expandable rows
const expandButtons = document.querySelectorAll('.expand-btn');
expandButtons.forEach(button => {
    button.addEventListener('click', () => {
        const row = button.closest('tr');
        const details = row.nextElementSibling;
        details.classList.toggle('expanded');
        button.querySelector('i').classList.toggle('fa-chevron-down');
        button.querySelector('i').classList.toggle('fa-chevron-up');
    });
});

// Handle table sorting
const sortableHeaders = document.querySelectorAll('.sortable');
let currentSort = { column: 'date', direction: 'desc' };

sortableHeaders.forEach(header => {
    header.addEventListener('click', () => {
        const column = header.dataset.sort;
        const direction = currentSort.column === column && currentSort.direction === 'asc' ? 'desc' : 'asc';
        
        // Update sort indicators
        sortableHeaders.forEach(h => h.querySelector('i').className = 'fas fa-sort');
        header.querySelector('i').className = `fas fa-sort-${direction === 'asc' ? 'up' : 'down'}`;
        
        // Sort the table
        const tbody = document.querySelector('.reports-table tbody');
        const rows = Array.from(tbody.querySelectorAll('tr.report-row'));
        const sortedRows = rows.sort((a, b) => {
            let aVal = a.children[getColumnIndex(column)].textContent;
            let bVal = b.children[getColumnIndex(column)].textContent;
            
            if (column === 'date') {
                aVal = new Date(aVal);
                bVal = new Date(bVal);
            }
            
            if (direction === 'asc') {
                return aVal > bVal ? 1 : -1;
            } else {
                return aVal < bVal ? 1 : -1;
            }
        });

        // Reorder rows
        sortedRows.forEach(row => {
            const details = row.nextElementSibling;
            tbody.appendChild(row);
            tbody.appendChild(details);
        });

        currentSort = { column, direction };
    });
});

// Handle filters
const typeFilter = document.querySelector('.type-filter');
const statusFilter = document.querySelector('.status-filter');
const dateFromFilter = document.querySelector('.date-from');
const dateToFilter = document.querySelector('.date-to');

function filterReports() {
    const rows = document.querySelectorAll('.report-row');
    const type = typeFilter.value;
    const status = statusFilter.value;
    const dateFrom = dateFromFilter.value ? new Date(dateFromFilter.value) : null;
    const dateTo = dateToFilter.value ? new Date(dateToFilter.value) : null;

    rows.forEach(row => {
        const rowType = row.querySelector('.badge').textContent.toLowerCase();
        const rowStatus = row.querySelector('.status-badge').textContent.toLowerCase();
        const rowDate = new Date(row.children[2].textContent);
        
        const typeMatch = type === 'all' || rowType.includes(type);
        const statusMatch = status === 'all' || rowStatus.includes(status);
        const dateMatch = (!dateFrom || rowDate >= dateFrom) && (!dateTo || rowDate <= dateTo);

        const details = row.nextElementSibling;
        if (typeMatch && statusMatch && dateMatch) {
            row.style.display = '';
            if (details.classList.contains('expanded')) {
                details.style.display = '';
            }
        } else {
            row.style.display = 'none';
            details.style.display = 'none';
        }
    });
}

typeFilter.addEventListener('change', filterReports);
statusFilter.addEventListener('change', filterReports);
dateFromFilter.addEventListener('change', filterReports);
dateToFilter.addEventListener('change', filterReports);

// Helper function to get column index
function getColumnIndex(column) {
    const indices = {
        'reporter': 0,
        'type': 1,
        'date': 2,
        'status': 3
    };
    return indices[column];
}

// Live Map specific controls
const liveMapControls = document.querySelector('.live-map-controls');
if (liveMapControls) {
    // Category toggles for live map
    const categoryButtons = liveMapControls.querySelectorAll('.category-toggles button');
    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            button.classList.add('active');
            
            // Get selected category
            const category = button.dataset.category;
            
            // Remove all existing markers
            if (currentMarkers) {
                currentMarkers.forEach(marker => marker.remove());
            }
            currentMarkers = [];

            // Filter and add new markers
            let filteredPings = allPings;
            if (category !== 'all') {
                filteredPings = allPings.filter(ping => ping.type === category);
            }

            // Add filtered markers to the live map
            if (liveMap) {
                filteredPings.forEach(ping => {
                    const el = document.createElement('div');
                    el.className = `marker ${ping.type}`;
                    el.style.backgroundColor = getMarkerColor(ping.type);
                    el.style.width = '28px';
                    el.style.height = '28px';
                    el.style.borderRadius = '50%';
                    el.style.border = '3px solid white';
                    el.style.boxShadow = '0 0 0 3px ' + getMarkerColor(ping.type);
                    el.style.zIndex = '1000';

                    const popup = new mapboxgl.Popup({ offset: 25 })
                        .setHTML(`
                            <div class="map-popup">
                                <div class="popup-header">
                                    <span class="popup-user">${ping.author}</span>
                                    <span class="popup-time">${formatTimestamp(ping.timestamp)}</span>
                                </div>
                                <p class="popup-message">${ping.description}</p>
                            </div>
                        `);

                    const marker = new mapboxgl.Marker(el)
                        .setLngLat(ping.coordinates)
                        .setPopup(popup)
                        .addTo(liveMap);

                    currentMarkers.push(marker);
                });
            }

            // Update the pings feed
            updatePingsFeed(filteredPings);
        });
    });

    // Time filter for live map
    const timeFilter = document.getElementById('live-time-filter');
    if (timeFilter) {
        timeFilter.addEventListener('change', (e) => {
            filterPingsByTime(e.target.value);
        });
    }

    // Place ping button for live map
    const livePlacePingBtn = document.getElementById('live-place-ping');
    if (livePlacePingBtn) {
        livePlacePingBtn.addEventListener('click', () => {
            if (!liveMap) return;

            liveMap.getCanvas().style.cursor = 'crosshair';
            
            const onClick = (e) => {
                const coordinates = e.lngLat;
                
                // Create a new ping at the clicked location
                const el = document.createElement('div');
                el.className = 'marker new-ping';
                
                new mapboxgl.Marker(el)
                    .setLngLat(coordinates)
                    .addTo(liveMap);
                
                // Reset cursor and remove click handler
                liveMap.getCanvas().style.cursor = '';
                liveMap.off('click', onClick);
                
                // Show pin modal if it exists
                if (pinModal) {
                    document.getElementById('pin-location').value = `${coordinates.lat}, ${coordinates.lng}`;
                    pinModal.classList.add('active');
                }
            };
            
            liveMap.once('click', onClick);
        });
    }
}

// Chat Functionality
document.addEventListener('DOMContentLoaded', () => {
    // Chat List Item Click Handler
    const chatItems = document.querySelectorAll('.chat-item');
    chatItems.forEach(item => {
        item.addEventListener('click', () => {
            // Remove active class from all items
            chatItems.forEach(chat => chat.classList.remove('active'));
            // Add active class to clicked item
            item.classList.add('active');
            
            // Update chat window based on selected chat
            updateChatWindow(item.dataset.chatId);
        });
    });

    // New Chat Button Animation
    const newChatBtn = document.querySelector('.new-chat-btn');
    if (newChatBtn) {
        newChatBtn.addEventListener('mouseenter', () => {
            newChatBtn.style.transform = 'rotate(15deg) scale(1.1)';
        });
        newChatBtn.addEventListener('mouseleave', () => {
            newChatBtn.style.transform = 'none';
        });
        newChatBtn.addEventListener('click', () => {
            // Show new chat dialog (implementation depends on your needs)
            console.log('New chat clicked');
        });
    }

    // Emoji Picker
    const emojiPicker = document.querySelector('.emoji-picker');
    const reactBtns = document.querySelectorAll('.react-btn');
    
    reactBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const rect = btn.getBoundingClientRect();
            emojiPicker.style.bottom = `${window.innerHeight - rect.top + 10}px`;
            emojiPicker.style.right = `${window.innerWidth - rect.right + 30}px`;
            emojiPicker.classList.add('active');
            
            // Store the message element for later use
            emojiPicker.dataset.targetMessage = btn.closest('.message').dataset.messageId;
        });
    });

    // Close emoji picker when clicking outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.emoji-picker') && !e.target.closest('.react-btn')) {
            emojiPicker.classList.remove('active');
        }
    });

    // Handle emoji selection
    const emojiButtons = document.querySelectorAll('.emoji-btn');
    emojiButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const messageId = emojiPicker.dataset.targetMessage;
            const message = document.querySelector(`[data-message-id="${messageId}"]`);
            if (message) {
                addReaction(message, btn.textContent);
            }
            emojiPicker.classList.remove('active');
        });
    });

    // Message Action Handlers
    document.querySelectorAll('.action-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const action = btn.classList.contains('reply-btn') ? 'reply' :
                          btn.classList.contains('forward-btn') ? 'forward' :
                          btn.classList.contains('edit-btn') ? 'edit' :
                          btn.classList.contains('unsend-btn') ? 'unsend' : null;
            
            const message = btn.closest('.message');
            handleMessageAction(action, message);
        });
    });

    // Function to handle message actions
    function handleMessageAction(action, message) {
        switch(action) {
            case 'reply':
                // Show reply interface
                const input = document.querySelector('.chat-input-container input');
                input.value = `Replying to ${message.querySelector('.message-author')?.textContent || 'message'}: `;
                input.focus();
                break;
            case 'forward':
                // Show forward dialog
                console.log('Forward message');
                break;
            case 'edit':
                // Enable editing for the message
                const content = message.querySelector('p');
                const originalText = content.textContent;
                content.contentEditable = true;
                content.focus();
                
                // Add save button
                const saveBtn = document.createElement('button');
                saveBtn.className = 'save-edit-btn';
                saveBtn.innerHTML = '<i class="fas fa-check"></i>';
                message.querySelector('.message-actions').appendChild(saveBtn);
                
                saveBtn.addEventListener('click', () => {
                    content.contentEditable = false;
                    saveBtn.remove();
                });
                break;
            case 'unsend':
                // Animate message removal
                message.style.animation = 'fadeOut 0.3s ease';
                setTimeout(() => message.remove(), 300);
                break;
        }
    }

    // Function to add reaction to a message
    function addReaction(message, emoji) {
        let reactions = message.querySelector('.message-reactions');
        if (!reactions) {
            reactions = document.createElement('div');
            reactions.className = 'message-reactions';
            message.querySelector('.message-content').appendChild(reactions);
        }

        // Check if reaction already exists
        const existingReaction = reactions.querySelector(`[data-emoji="${emoji}"]`);
        if (existingReaction) {
            const count = parseInt(existingReaction.dataset.count) + 1;
            existingReaction.dataset.count = count;
            existingReaction.querySelector('.count').textContent = count;
        } else {
            const reaction = document.createElement('div');
            reaction.className = 'reaction-badge';
            reaction.dataset.emoji = emoji;
            reaction.dataset.count = 1;
            reaction.innerHTML = `${emoji} <span class="count">1</span>`;
            reactions.appendChild(reaction);
        }
    }

    // Function to update chat window content
    function updateChatWindow(chatId) {
        const chatData = {
            'community': {
                title: 'Community Chat',
                onlineCount: '156 members online',
                messages: [
                    // Add your message data here
                ]
            },
            'watch': {
                title: 'Neighborhood Watch',
                onlineCount: '23 members online',
                messages: [
                    // Add your message data here
                ]
            },
            'safety': {
                title: 'Safety Committee',
                onlineCount: '12 members online',
                messages: [
                    // Add your message data here
                ]
            },
            'events': {
                title: 'Community Events',
                onlineCount: '89 members online',
                messages: [
                    // Add your message data here
                ]
            }
        };

        const data = chatData[chatId];
        if (data) {
            document.querySelector('.chat-window-title h3').textContent = data.title;
            document.querySelector('.online-count').textContent = data.onlineCount;
            // Update messages (implementation depends on your needs)
        }
    }
}); 